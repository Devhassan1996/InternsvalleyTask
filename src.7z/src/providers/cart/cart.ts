import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

/*
  Generated class for the CartProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class CartProvider {
  total: number = 0;
  cart: any[] = [];

  constructor(public http: HttpClient) {
    console.log('Hello CartProvider Provider');
  }

  addToCart(product: any) {
    this.cart.push(product);
    this.total += parseFloat(product.prices.price);
  }

  removeFromCart(product:any, index) {
    const position = this.cart.findIndex((product) => {
      return product.id === this.cart[index].id;
    });
    this.cart.splice(position, 1);
    this.total -= parseFloat(product.prices.price);
  }

}
