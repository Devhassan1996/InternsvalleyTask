import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController } from 'ionic-angular';
import { ApiProvider } from '../../providers/api/api';
import { CartProvider } from '../../providers/cart/cart';

@Component({
  selector: 'page-list',
  templateUrl: 'list.html'
})
export class ListPage {
  list: any = [];
 
  constructor(public navCtrl: NavController, public navParams: NavParams, public api: ApiProvider, public loadingCtrl: LoadingController, public cart: CartProvider) {
    this.getList();
  }

  getList() {
    let loading = this.loadingCtrl.create({ content: "Getting List, Please wait..."});
    loading.present();
    this.api.getList().subscribe((res: any) => {
      this.list = res.products;
      loading.dismiss();
    })
  }
  addToCart(product) {
    this.cart.addToCart(product);
  }
  
  removeFromCart(product, index) {
    this.cart.removeFromCart(product, index);
  }
}
